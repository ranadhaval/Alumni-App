class SigninRes {
  bool? success;
  Data? data;
  String? token;

  SigninRes({this.success, this.data, this.token});

  SigninRes.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
    token = json['token'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['success'] = this.success;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    data['token'] = this.token;
    return data;
  }
}

class Data {
  int? id;
  String? userCode;
  String? firstName;
  String? lastName;
  String? email;
  String? status;
  String? domainName;
  String? role;
  String? createdAt;
  String? updatedAt;
  Null? parentUserId;
  Null? pictureUrl;
  String? organizationName;
  String? jobTitle;
  bool? isApproved;
  String? roleCategory;
  bool? isProfileCompleted;

  Data(
      {this.id,
      this.userCode,
      this.firstName,
      this.lastName,
      this.email,
      this.status,
      this.domainName,
      this.role,
      this.createdAt,
      this.updatedAt,
      this.parentUserId,
      this.pictureUrl,
      this.organizationName,
      this.jobTitle,
      this.isApproved,
      this.roleCategory,
      this.isProfileCompleted});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userCode = json['user_code'];
    firstName = json['first_name'];
    lastName = json['last_name'];
    email = json['email'];
    status = json['status'];
    domainName = json['domain_name'];
    role = json['role'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
    parentUserId = json['parent_user_id'];
    pictureUrl = json['picture_url'];
    organizationName = json['organization_name'];
    jobTitle = json['job_title'];
    isApproved = json['is_approved'];
    roleCategory = json['role_category'];
    isProfileCompleted = json['is_profile_completed'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_code'] = this.userCode;
    data['first_name'] = this.firstName;
    data['last_name'] = this.lastName;
    data['email'] = this.email;
    data['status'] = this.status;
    data['domain_name'] = this.domainName;
    data['role'] = this.role;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    data['parent_user_id'] = this.parentUserId;
    data['picture_url'] = this.pictureUrl;
    data['organization_name'] = this.organizationName;
    data['job_title'] = this.jobTitle;
    data['is_approved'] = this.isApproved;
    data['role_category'] = this.roleCategory;
    data['is_profile_completed'] = this.isProfileCompleted;
    return data;
  }
}