import 'package:alumni/Constants/image_constant.dart';
import 'package:alumni/Pages/Sign%20in/SigninRes/signin_data.dart';
import 'package:alumni/Pages/Signup/UI/signup.dart';
import 'package:alumni/Widgets/Widgets/appbar.dart';
import 'package:alumni/themeFiles/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:alumni/Widgets/Widgets/custom_button.dart';
import 'package:alumni/Widgets/Widgets/custom_text.dart';
import 'package:alumni/Widgets/classes/widget_helper_class.dart';
import '../../../Constants/strings.dart';
import '../../../Functions/common.dart';
import '../../../themeFiles/app_typography.dart';
import '../../../themeFiles/layout_helper.dart';

class SignIn extends StatefulWidget {
  static String routeName = '/signin';
  const SignIn({super.key});
  @override
  State<SignIn> createState() => _SignInState();
}

class _SignInState extends State<SignIn> {
  @override
  Widget build(BuildContext context) {
    return LayoutHelper.pageContainer(
        onTap: () {
          FocusScope.of(context).unfocus();
        },
        backgroundColor: AppColors.getColor(AppColorsEnum.secondaryColor),
        horizontalPadding: 15,
        appBar: appBar(
            color: AppColors.getColor(AppColorsEnum.secondaryColorAppbar)),
        child: _body(context));
  }

  _body(context) {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          LayoutHelper.height20(),
          Image.asset(
            ImageConstant.alumniLogo,
            height: height * 0.125,
          ),
          LayoutHelper.height20(),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 5,
                backgroundColor:
                    AppColors.getSingleColor(AppColorsEnum.primary),
              ),
              LayoutHelper.width10(),
              CustomText(
                  textKey: AppStrings.signIn,
                  style: AppTextStyle.titleLarge,
                  textAlign: TextAlign.center,
                  color: AppColors.getSingleColor(AppColorsEnum.primary)),
              Text(
                AppStrings.devider,
                style: TextStyle(
                    fontSize: 20,
                    color: AppColors.getSingleColor(AppColorsEnum.white)),
              ),
              InkWell(
                onTap: () =>
                    navigateToPageWithoutReplaceMentNamed(Signup.routeName),
                child: CustomText(
                  textKey: AppStrings.register,
                  style: AppTextStyle.titleLarge,
                  textAlign: TextAlign.center,
                  color: AppColors.getSingleColor(AppColorsEnum.white),
                ),
              ),
            ],
          ),
          LayoutHelper.height30(),
          Align(
            alignment: Alignment.centerLeft,
            child: CustomText(
              textKey: AppStrings.enterDetailsToLogin,
              style: AppTextStyle.bodyLarge.copyWith(fontSize: 18),
              textAlign: TextAlign.left,
              color: AppColors.getSingleColor(AppColorsEnum.white),
            ),
          ),
          LayoutHelper.height10(),
          for (int i = 0; i < 2; i++)
            ...WidgetHelper.getNameAndInputField(
              names[i],
              controllers[i],
              context,
              isEmail: i == 0 ? true : false,
              isPass: i == 1,
              // readOnly: readOnlyList[i],
              // suffixicon: i == 1 ? suffixIcon(context) : null,
              isShowIcon: true,
              prefixIcon: Image.asset(ImageConstant.accountLogo, width: 1),
            ),
          Align(
              alignment: Alignment.centerRight,
              child: GestureDetector(
                  onTap: () {},
                  child: CustomText(
                    textKey: AppStrings.forgetEmail,
                    color: AppColors.getSingleColor(AppColorsEnum.white),
                  ))),
          LayoutHelper.height30(),
          CustomButtonElevated(
              type: ButtonType.primary,
              text: AppStrings.login,
              onTap: () async {
                completeSignin(context);
              }),
          LayoutHelper.height30(),
          RichText(
            textAlign: TextAlign.center,
            text: TextSpan(children: [
              TextSpan(
                  text: AppStrings.acceptTerms,
                  style: AppTextStyle.bodyMedium.copyWith(
                      color: AppColors.getColor(AppColorsEnum.white))),
              TextSpan(
                text: AppStrings.terms,
                style: AppTextStyle.titleSmall
                    .copyWith(color: AppColors.getColor(AppColorsEnum.primary)),
              ),
              TextSpan(
                text: AppStrings.and,
                style: AppTextStyle.bodyMedium
                    .copyWith(color: AppColors.getColor(AppColorsEnum.white)),
              ),
              TextSpan(
                  text: AppStrings.privacy,
                  style: AppTextStyle.titleSmall.copyWith(
                      color: AppColors.getColor(AppColorsEnum.primary))),
            ]),
          )
        ],
      ),
    );
  }

  final _formKey = GlobalKey<FormState>();

  List<TextEditingController> controllers = getTextController(2);
  List<String> names = [
    AppStrings.enterRegisteredEmail,
    AppStrings.password,
  ];
  Widget suffixIcon(context) => InkWell(
        onTap: () {
          showModalBottomSheet(
              context: context,
              builder: (con) {
                return Container(
                  height: height * 0.32,
                  child: Column(
                    children: [
                      LayoutHelper.height10(),
                      Container(
                        height: height * 0.3,
                        child: ListView.builder(
                          itemCount: branchAndSchoolList.length,
                          itemBuilder: (context, index) {
                            return ListTile(
                              onTap: () {
                                setState(() {
                                  controllers[0].text =
                                      branchAndSchoolList[index];
                                  Navigator.pop(context);
                                });
                              },
                              subtitle: Text(branchAndSchoolList[index]),
                            );
                          },
                        ),
                      )
                    ],
                  ),
                );
              });
        },
        child: Icon(
          Icons.expand_circle_down_rounded,
          size: 30,
          color: AppColors.getSingleColor(AppColorsEnum.primary),
        ),
      );

  List<bool> readOnlyList = [true, false];

  List<String> branchAndSchoolList = [
    "Shantilal Shah Engineering collage - IT",
    "Shantilal Shah Engineering collage - Chemical",
    "Shantilal Shah Engineering collage - Production",
    "Shantilal Shah Engineering collage - Mechenical",
    "L.D Engineering Collage - IT",
    "L.D Engineering Collage - Chemical",
    "L.D Engineering Collage - Production",
    "L.D Engineering Collage - Production",
  ];

  SigninResponseData signinResponseData = SigninResponseData();

  // void completeSignin(context) async {
  //   if (_formKey.currentState!.validate()) {
  //     Navigator.of(context)
  //         .push(MaterialPageRoute(builder: (_) => const Welcome()));
  //   }
  //   //else {
  //   // ScaffoldMessenger.of(context!).showSnackBar(
  //   //   WidgetHelper.getSnackBar(
  //   //       context!, AppStrings.pleaseCheckAllFeilds, Colors.red),
  //   // );
  //   // }
  // }

  void completeSignin(context) async {
    if (_formKey.currentState != null && _formKey.currentState!.validate()) {
      try {
        signinResponseData.getSigin(
          email: controllers[0].text,
          password: controllers[1].text,
        );
      } catch (e) {
        ScaffoldMessenger.of(context!).showSnackBar(
          WidgetHelper.getSnackBar(context!, e.toString(), Colors.red),
        );
      }
    } else {
      ScaffoldMessenger.of(context!).showSnackBar(
        WidgetHelper.getSnackBar(
            context!, AppStrings.pleaseCheckAllFeilds, Colors.red),
      );
    }
  }
}
