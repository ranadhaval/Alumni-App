import 'package:alumni/Pages/Home/home.dart';
import 'package:alumni/Pages/Sign%20in/Model/Request/signin_request.dart';
import 'package:alumni/Pages/Sign%20in/Provider/signin_provider.dart';
import 'package:alumni/Pages/Welcome/welcomepage.dart';
import 'package:alumni/Services/webservices/response_model.dart';
import 'package:alumni/Widgets/classes/widget_helper_class.dart';
import 'package:alumni/themeFiles/app_typography.dart';
import 'package:flutter/material.dart';

class SigninResponseData {
  getSigin({
    required String email,
    required String password,
  }) {
    SigninReq signinReq = SigninReq(
      email: email,
      password: password,
    );

    SigninProvider().getSignin(
        signinReq: signinReq,
        onSuccess: ((ResponseModel responseModel) {
          try {
            if (responseModel.statusCode == 200) {
              print("green");
              ScaffoldMessenger.of(context!).showSnackBar(
                WidgetHelper.getSnackBar(
                    context!, "Succesfully signin", Colors.green),
              );

              Navigator.of(context!)
                  .push(MaterialPageRoute(builder: (_) => const Welcome()));
            } else {
              print("red");

              ScaffoldMessenger.of(context!).showSnackBar(
                WidgetHelper.getSnackBar(
                    context!, "failed into signin", Colors.red),
              );
            }
          } catch (e) {
            ScaffoldMessenger.of(context!).showSnackBar(
              WidgetHelper.getSnackBar(
                  context!, "failed into signin", Colors.red),
            );
          }
        }),
        onError: ((ResponseModel responseModel) {
          ScaffoldMessenger.of(context!).showSnackBar(
            WidgetHelper.getSnackBar(
                context!, responseModel.message.toString(), Colors.red),
          );
          print("failed");
        }));
  }
}
